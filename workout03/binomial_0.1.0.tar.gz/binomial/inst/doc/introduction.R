## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(binomial)

## ------------------------------------------------------------------------
# For example, if we cant to calculate the number of combinations in which 2 successes can occur in 5 trials. 
 bin_choose(n = 5, k = 2)

## ------------------------------------------------------------------------
# For example, we can compute the number of combinations in which 1 or 2 or 3 successes can occur in 5 trials respectively.
bin_choose(5, 1:3)

## ------------------------------------------------------------------------
# probability of getting 2 successes in 5 trials(assuming prob of success = 0.5)
bin_probability(success = 2, trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
# binomial probability distribution
dis1 <- bin_distribution(trials = 5, prob = 0.5)

## ------------------------------------------------------------------------
plot(dis1)

## ------------------------------------------------------------------------
dis2 <- bin_cumulative(trials = 5, prob = 0.5)
dis2

## ------------------------------------------------------------------------
plot(dis2)

## ------------------------------------------------------------------------
bin1 <- bin_variable(trials = 10, prob = 0.3)

## ------------------------------------------------------------------------
print(bin1)

## ------------------------------------------------------------------------
summary(bin1)

## ------------------------------------------------------------------------
print(bin1)

